// screens/ProfileScreen.js
import React from 'react';
import { View, Text, Button, StyleSheet, Image } from 'react-native';
import colors from './coloures/colors'; // Corrected path

const ProfileScreen = ({ onNavigate }) => {
  return (
    <View style={styles.container}>
      <Image source={require('./assets/christofell.jpg')} style={styles.chefImage} />
      <Text style={styles.title}>Chef Christofell</Text>
      <Text style={styles.bio}>
        Chef Christofell is a renowned culinary expert with over 20 years of experience in the kitchen. 
        Known for his innovative approach to traditional dishes, he has worked in some of the most prestigious 
        restaurants around the world. His passion for cooking began at a young age, and he has since dedicated 
        his life to perfecting his craft. Chef Christofell believes in using fresh, locally sourced ingredients 
        to create meals that are not only delicious but also sustainable.
      </Text>
      <Button title="Back" onPress={() => onNavigate('Home')} color={colors.primary} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: colors.background,
  },
  chefImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 16,
    color: colors.text,
  },
  bio: {
    fontSize: 16,
    color: colors.text,
    textAlign: 'center',
    marginBottom: 16,
  },
});

export default ProfileScreen;
