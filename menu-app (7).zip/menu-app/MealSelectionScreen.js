import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Button } from 'react-native';

const MealSelectionScreen = ({ menu, onBack, onCheckout }) => {
  const [selectedMeals, setSelectedMeals] = useState([]);

  const toggleMealSelection = (meal) => {
    if (selectedMeals.includes(meal.id)) {
      setSelectedMeals(selectedMeals.filter(id => id !== meal.id));
    } else {
      setSelectedMeals([...selectedMeals, meal.id]);
    }
  };

  const handleCheckout = () => {
    const selectedItems = menu.filter(meal => selectedMeals.includes(meal.id));
    onCheckout(selectedItems);
  };

  const renderMealItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.mealItem, selectedMeals.includes(item.id) && styles.selectedMeal]}
      onPress={() => toggleMealSelection(item)}
    >
      <Text style={styles.mealName}>{item.name}</Text>
      <Text style={styles.mealPrice}>R{item.price.toFixed(2)}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Select Your Meals</Text>
      <FlatList
        data={menu}
        renderItem={renderMealItem}
        keyExtractor={item => item.id.toString()}
      />
      <Button title="Proceed to Checkout" onPress={handleCheckout} disabled={selectedMeals.length === 0} />
      <Button title="Back" onPress={onBack} color="#FF6347" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  mealItem: {
    padding: 15,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    marginBottom: 10,
    backgroundColor: '#f9f9f9',
  },
  selectedMeal: {
    backgroundColor: '#d1e7fd',
  },
  mealName: {
    fontSize: 18,
  },
  mealPrice: {
    fontSize: 16,
    color: '#888',
  },
});

export default MealSelectionScreen;
