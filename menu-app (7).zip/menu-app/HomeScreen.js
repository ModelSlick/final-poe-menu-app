// HomeScreen.js
import React from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity } from 'react-native';

const HomeScreen = ({
  onStartersNavigate,
  onMainCourseNavigate,
  onDessertNavigate,
  onEnterMenuNavigate,
  onMealSelectionNavigate,
  onRatingNavigate,
  onProfileNavigate,
  onVeganNavigate,
  onNonVeganNavigate,
  averageStarterPrice,
  averageMainCoursePrice,
  averageDessertPrice,
}) => (
  <View style={styles.container}>
    <Text style={styles.title}>Welcome to the Menu App</Text>
    <Text style={styles.subtitle}>Average Prices:</Text>
    <Text style={styles.price}>Starters: R{averageStarterPrice}</Text>
    <Text style={styles.price}>Main Courses: R{averageMainCoursePrice}</Text>
    <Text style={styles.price}>Desserts: R{averageDessertPrice}</Text>
    
    <TouchableOpacity style={styles.button} onPress={onStartersNavigate}>
      <Text style={styles.buttonText}>Starters</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={onMainCourseNavigate}>
      <Text style={styles.buttonText}>Main Courses</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={onDessertNavigate}>
      <Text style={styles.buttonText}>Desserts</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={onEnterMenuNavigate}>
      <Text style={styles.buttonText}>Enter Menu</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={onMealSelectionNavigate}>
      <Text style={styles.buttonText}>Meal Selection</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={onRatingNavigate}>
      <Text style={styles.buttonText}>Rating</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={onProfileNavigate}>
      <Text style={styles.buttonText}>Profile</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={onVeganNavigate}>
      <Text style={styles.buttonText}>Vegan Options</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={onNonVeganNavigate}>
      <Text style={styles.buttonText}>Non-Vegan Options</Text>
    </TouchableOpacity>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  subtitle: {
    fontSize: 18,
    marginVertical: 10,
  },
  price: {
    fontSize: 16,
    marginVertical: 5,
  },
  button: {
    backgroundColor: '#4CAF50', // Green background
    borderRadius: 5,
    paddingVertical: 15,
    paddingHorizontal: 30,
    width: '80%', // Width of the button
    marginVertical: 10, // Space between buttons
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF', // White text
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default HomeScreen;
