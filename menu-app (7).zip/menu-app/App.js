// App.js
import React, { useState } from 'react';
import { View } from 'react-native';
import LoginScreen from './LoginScreen';
import HomeScreen from './HomeScreen';
import StarterScreen from './Starter';
import MainCourseScreen from './MainCourse';
import DessertScreen from './Desert';
import CheckoutScreen from './CheckoutScreen';
import EnterMenuScreen from './EnterMenuScreen';
import MealSelectionScreen from './MealSelectionScreen';
import RatingScreen from './RatingScreen';
import CartScreen from './CartScreen';
import ProfileScreen from './ProfileScreen';
import VeganScreen from './veganScreen';
import NonVeganScreen from './NonVeganScreen';

const App = () => {
  const [currentScreen, setCurrentScreen] = useState('Login');
  const [selectedMenuItems, setSelectedMenuItems] = useState([]);

  const menu = [
    // Main menu items
    { id: 1, name: 'Burger', price: 120.99, vegan: false, image: 'https://cmx.weightwatchers.com/assets-proxy/weight-watchers/image/upload/v1594406683/visitor-site/prod/ca/burgers_mobile_my18jv' },
    { id: 2, name: 'Burrito', price: 155.99, vegan: false, image: 'https://www.isleofwightmeat.co.uk/wp-content/uploads/2020/03/shutterstock_1349138753-scaled.jpg' },
    { id: 3, name: 'Non Vegan Share Meal', price: 500.99, vegan: false, image: 'https://assets.cntraveller.in/photos/60b9f9405b07c77d362e4778/master/pass/Street-food-non-veg.jpg.jpg' },
    { id: 4, name: 'Pizza', price: 149.99, vegan: false, image: 'https://assets.teenvogue.com/photos/5ab665d06d36ed4396878433/master/pass/GettyImages-519526540.jpg' },
    { id: 5, name: 'Vegan Salad', price: 90.99, vegan: true, image: 'https://simple-veganista.com/wp-content/uploads/2019/07/vegan-cobb-salad_.jpg' },
    { id: 6, name: 'Vegan Burger', price: 129.99, vegan: true, image: 'https://bing.com/th?id=OSK.cf9e34d422fc66b8b843f45a8cfa5577' },
    { id: 7, name: 'Vegan Burrito', price: 159.99, vegan: true, image: 'https://bing.com/th?id=OSK.dc66d76c516e613084a9334d9d914978' },
    { id: 8, name: 'Vegan Share Meal', price: 400.99, vegan: true, image: 'https://thegreenloot.com/wp-content/uploads/2018/05/vegan-meal-prep-weight-loss-1024x1024.jpg' },
    { id: 9, name: 'Vegan Pizza', price: 149.99, vegan: true, image: 'https://bing.com/th?id=OSK.fc0caf96d439a518133cde1caa7772ad' },
    
    // Starters
    { id: 10, name: 'Garlic Bread', price: 49.99, vegan: true, image: 'https://bing.com/th?id=OSK.d56789ad6a34bfb6d123b45c3f8c1123' },
    { id: 11, name: 'Tomato Soup', price: 59.99, vegan: true, image: 'https://bing.com/th?id=OSK.a123b456c789d012e345f6789123a456' },
    { id: 12, name: 'Chicken Wings', price: 99.99, vegan: false, image: 'https://bing.com/th?id=OSK.b123c456d789e012f345g6789123b456' },
    
    // Desserts
    { id: 13, name: 'Chocolate Cake', price: 89.99, vegan: false, image: 'https://bing.com/th?id=OSK.c56789ef1234b678d9abcd1234e5678' },
    { id: 14, name: 'Vegan Brownie', price: 79.99, vegan: true, image: 'https://bing.com/th?id=OSK.d123456e7890b123c456d7890123e456' },
    { id: 15, name: 'Ice Cream Sundae', price: 69.99, vegan: false, image: 'https://bing.com/th?id=OSK.e1234567890b123c456d789e0123f456' },
  ];

  // Function to calculate average price
  const calculateAveragePrice = (items) => {
    if (items.length === 0) return 0;
    const total = items.reduce((sum, item) => sum + item.price, 0);
    return (total / items.length).toFixed(2);
  };

  // Calculate average prices
  const averageStarterPrice = calculateAveragePrice(menu.filter(item => item.id >= 10 && item.id <= 12));
  const averageMainCoursePrice = calculateAveragePrice(menu.filter(item => item.id >= 1 && item.id <= 9));
  const averageDessertPrice = calculateAveragePrice(menu.filter(item => item.id >= 13 && item.id <= 15));

  const handleNavigation = (screen) => {
    setCurrentScreen(screen);
  };

  const handleCheckout = (items) => {
    setSelectedMenuItems(items);
    handleNavigation('Checkout');
  };

  return (
    <View style={{ flex: 1 }}>
      {currentScreen === 'Login' && <LoginScreen onNavigate={() => handleNavigation('Home')} />}
      {currentScreen === 'Home' && (
        <HomeScreen
          onStartersNavigate={() => handleNavigation('Starter')}
          onMainCourseNavigate={() => handleNavigation('MainCourse')}
          onDessertNavigate={() => handleNavigation('Dessert')}
          onEnterMenuNavigate={() => handleNavigation('EnterMenu')}
          onMealSelectionNavigate={() => handleNavigation('MealSelection')}
          onRatingNavigate={() => handleNavigation('Rating')}
          onCartNavigate={() => handleNavigation('Cart')}
          onProfileNavigate={() => handleNavigation('Profile')}
          onVeganNavigate={() => handleNavigation('Vegan')}
          onNonVeganNavigate={() => handleNavigation('NonVegan')}
          averageStarterPrice={averageStarterPrice}
          averageMainCoursePrice={averageMainCoursePrice}
          averageDessertPrice={averageDessertPrice}
        />
      )}
      {currentScreen === 'Starter' && (
        <StarterScreen
          menu={menu.filter(item => item.id >= 10 && item.id <= 12)}
          onBack={() => handleNavigation('Home')}
          onCheckout={handleCheckout}
        />
      )}
      {currentScreen === 'MainCourse' && (
        <MainCourseScreen
          menu={menu.filter(item => item.id >= 1 && item.id <= 9)} // Adjust as needed for your main courses
          onBack={() => handleNavigation('Home')}
          onCheckout={handleCheckout}
        />
      )}
      {currentScreen === 'Dessert' && (
        <DessertScreen
          menu={menu.filter(item => item.id >= 13 && item.id <= 15)}
          onBack={() => handleNavigation('Home')}
          onCheckout={handleCheckout}
        />
      )}
      {currentScreen === 'Checkout' && (
        <CheckoutScreen
          selectedItems={selectedMenuItems}
          onBack={() => handleNavigation('Home')}
        />
      )}
      {currentScreen === 'EnterMenu' && <EnterMenuScreen onPress={() => handleNavigation('Home')} />}
      {currentScreen === 'MealSelection' && <MealSelectionScreen onBack={() => handleNavigation('Home')} />}
      {currentScreen === 'Rating' && <RatingScreen onBack={() => handleNavigation('Home')} />}
      {currentScreen === 'Cart' && <CartScreen onBack={() => handleNavigation('Home')} />}
      {currentScreen === 'Profile' && <ProfileScreen onBack={() => handleNavigation('Home')} />}
      {currentScreen === 'Vegan' && <VeganScreen onBack={() => handleNavigation('Home')} />}
      {currentScreen === 'NonVegan' && <NonVeganScreen onBack={() => handleNavigation('Home')} />}
    </View>
  );
};

export default App;
