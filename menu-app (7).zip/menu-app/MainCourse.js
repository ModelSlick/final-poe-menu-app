// MainCourseScreen.js
import React, { useState } from 'react';
import { View, Text, FlatList, Button, Image, StyleSheet } from 'react-native';

const MainCourseScreen = ({ menu, onBack, onCheckout }) => {
  const [selectedItems, setSelectedItems] = useState([]);

  const toggleSelection = (itemId) => {
    setSelectedItems((prevSelected) => {
      if (prevSelected.includes(itemId)) {
        // If already selected, remove it from the selection
        return prevSelected.filter(id => id !== itemId);
      } else {
        // Otherwise, add it to the selection
        return [...prevSelected, itemId];
      }
    });
  };

  const handleCheckout = () => {
    const selectedMenuItems = menu.filter(item => selectedItems.includes(item.id));
    onCheckout(selectedMenuItems); // Pass selected items to checkout
  };

  return (
    <View style={styles.container}>
      <Button title="Back to Home" onPress={onBack} />
      <Text style={styles.title}>Main Courses</Text>
      <FlatList
        data={menu}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.menuItemContainer}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.itemDetails}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text>R{item.price.toFixed(2)}</Text>
              <Button
                title={selectedItems.includes(item.id) ? 'Deselect' : 'Select'}
                onPress={() => toggleSelection(item.id)}
              />
            </View>
          </View>
        )}
      />
      <Button
        title="Go to Checkout"
        onPress={handleCheckout}
        disabled={selectedItems.length === 0}
        color="#4CAF50"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  menuItemContainer: {
    flexDirection: 'row',
    marginBottom: 10,
    alignItems: 'center',
  },
  image: {
    width: 50,
    height: 50,
  },
  itemDetails: {
    marginLeft: 10,
    flex: 1,
  },
  itemName: {
    fontSize: 18,
  },
});

export default MainCourseScreen;
