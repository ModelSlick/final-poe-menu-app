import React, { useState } from 'react';
import { View, Text, Image, FlatList, TouchableOpacity, Button, StyleSheet } from 'react-native';

const veganScreen = ({ menu = [], onNavigate }) => {
  const [selectedDishes, setSelectedDishes] = useState([]);
  const veganMenu = Array.isArray(menu) ? menu.filter(item => item.vegan) : [];

  const handleSelectDish = (item) => {
    setSelectedDishes(prevSelected => {
      if (prevSelected.some(dish => dish.id === item.id)) {
        return prevSelected.filter(dish => dish.id !== item.id);
      } else {
        return [...prevSelected, item];
      }
    });
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity onPress={() => handleSelectDish(item)} style={styles.itemContainer}>
      <Image source={{ uri: item.image }} style={styles.itemImage} />
      <View>
        <Text style={styles.itemName}>{item.name}</Text>
        <Text style={styles.itemPrice}>{`$${item.price.toFixed(2)}`}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={veganMenu}
        renderItem={renderItem}
        keyExtractor={item => item.id.toString()}
      />
      <Button title="Checkout" onPress={() => onNavigate('Checkout')} color="#841584" />
      <Button title="Back" onPress={() => onNavigate('Menu')} color="#841584" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  itemContainer: {
    flexDirection: 'row',
    margin: 10,
    alignItems: 'center',
  },
  itemImage: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  itemPrice: {
    fontSize: 14,
    color: 'gray',
  },
});

export default VeganScreen;
