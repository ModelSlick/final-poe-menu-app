import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const MenuScreen = ({ menu }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Menu Screen</Text>
      {/* Render your menu items here */}
      <Button title="Go to Starters" onPress={() => { /* Navigate to Starters */ }} />
      <Button title="Go to Main Courses" onPress={() => { /* Navigate to Main Courses */ }} />
      <Button title="Go to Desserts" onPress={() => { /* Navigate to Desserts */ }} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
});

export default MenuScreen;

