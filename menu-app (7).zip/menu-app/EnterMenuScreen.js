import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

const EnterMenuScreen = ({ onNavigateToMealSelection, onAddMeal }) => {
  const [mealName, setMealName] = useState('');
  const [mealPrice, setMealPrice] = useState('');
  const [mealType, setMealType] = useState('');

  const handleAddMeal = () => {
    if (!mealName || !mealPrice || !mealType) {
      Alert.alert('Error', 'Please fill in all fields.');
      return;
    }

    const newMeal = {
      id: Math.random(), // Ideally, use a proper ID system
      name: mealName,
      price: parseFloat(mealPrice),
      type: mealType, // You can further categorize this into 'starter', 'main', 'dessert', etc.
    };

    // Call the onAddMeal function passed from App.js to add the meal to the menu
    onAddMeal(newMeal);

    // Clear the input fields
    setMealName('');
    setMealPrice('');
    setMealType('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter Menu</Text>
      <TextInput
        style={styles.input}
        placeholder="Meal Name"
        value={mealName}
        onChangeText={setMealName}
      />
      <TextInput
        style={styles.input}
        placeholder="Meal Price"
        value={mealPrice}
        keyboardType="numeric"
        onChangeText={setMealPrice}
      />
      <TextInput
        style={styles.input}
        placeholder="Meal Type (e.g., Starter, Main, Dessert)"
        value={mealType}
        onChangeText={setMealType}
      />
      <Button title="Add Meal" onPress={handleAddMeal} />
      <Button title="Select Meals" onPress={onNavigateToMealSelection} color="#007BFF" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 10,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
});

export default EnterMenuScreen;

